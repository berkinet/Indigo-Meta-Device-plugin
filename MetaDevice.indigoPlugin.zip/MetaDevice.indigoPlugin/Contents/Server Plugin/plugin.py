#! /usr/bin/env python
# -*- coding: utf-8 -*-
####################
# Copyright (c) 2012, Berkinet, (AKA Richard Perlman) All rights reserved.

################################################################################
from berkinet import setLogLevel, versionCheck
import os # to run Group/Scene names shell script

################################################################################
class Plugin(indigo.PluginBase):
########################################
	def __init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs):
		indigo.PluginBase.__init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs)		
		(self.logLevel, self.debug) = setLogLevel(self, pluginDisplayName, pluginPrefs.get("showDebugInfo1", "1"))
	
	def __del__(self):
		indigo.PluginBase.__del__(self)

	########################################
	# Start, Stop and Restart
	########################################
	def startup(self):
		if self.logLevel > 2: indigo.server.log(u"Plugin startup.", type=self.pluginDisplayName)
		versionCheck(self, self.pluginDisplayName, self.logLevel, self.pluginId, self.pluginVersion)
	
	########################################
	def shutdown(self):
		if self.logLevel > 0: indigo.server.log(u"shutdown called", type=self.pluginDisplayName)
		
	########################################
	def closedPrefsConfigUi (self, valuesDict, UserCancelled):
		if UserCancelled is False:
			(self.logLevel, self.debug) = setLogLevel(self, self.pluginDisplayName, valuesDict["showDebugInfo1"])
								

	########################################
	# Meta Device Control/Action callback
	########################################
	def actionControlDimmerRelay(self, action, dev):
		# self.errorLog('ACTION:%s' % action)
		metaMode = dev.pluginProps['metaDevOnMode']
		# if hasattr(dev.pluginProps, 'metaDevBrightMode'):
		#	brightMode = dev.pluginProps['metaDevBrightMode']
		brightMode = dev.pluginProps.get('metaDevBrightMode', "")
			
		logType = self.pluginDisplayName + " " + dev.name
		if self.logLevel > 2: indigo.server.log(u"metaMode:%s" % (metaMode), type='Meta Device')
			
		###### TURN ON ######
		if action.deviceAction == indigo.kDeviceAction.TurnOn:
			if self.logLevel > 3: self.debugLog('device on:\n%s' % action)
			try:
				if metaMode == '1':
					indigo.insteon.sendSceneOn(int(dev.pluginProps['metaDevGroupScene']))				
				elif metaMode == '2':
					indigo.actionGroup.execute(int(dev.pluginProps['metaDevOnAction']))
				else:
					pass
					
				if self.logLevel > 0: indigo.server.log(u"Device \"%s\" %s" \
					% (dev.name, "on"), type=logType)
				dev.updateStateOnServer("onOffState", "on")
			except:
				indigo.server.log(u"send \"%s\" %s failed" % (dev.name, "on"), isError=True, type=logType)

		###### TURN OFF ######
		elif action.deviceAction == indigo.kDeviceAction.TurnOff:
			try:
				if self.logLevel > 3: self.debugLog('device off:\n%s' % action)
				if metaMode == '1':
					indigo.insteon.sendSceneOff(int(dev.pluginProps['metaDevGroupScene']))				
				elif metaMode == '2':
					indigo.actionGroup.execute(int(dev.pluginProps['metaDevOffAction']))
				else:
					pass

				if self.logLevel > 0: indigo.server.log(u"Device \"%s\" %s" \
					% (dev.name, "off"), type=logType)
				dev.updateStateOnServer("onOffState", "off")
			except:
				indigo.server.log(u"send \"%s\" %s failed" % (dev.name, "on"), isError=True, type=logType)

		###### TOGGLE ######
		elif action.deviceAction == indigo.kDeviceAction.Toggle:
			newOnState = not dev.onState
			newState = 'On'
			try:
				if dev.onState:
					newState = 'Off'
					if metaMode == '1':
						indigo.insteon.sendSceneOff(int(dev.pluginProps['metaDevGroupScene']))				
					elif metaMode == '2':
						indigo.actionGroup.execute(int(dev.pluginProps['metaDevOffAction']))
					else:
						pass

				else:
					if metaMode == '1':
						indigo.insteon.sendSceneOn(int(dev.pluginProps['metaDevGroupScene']))				
					elif metaMode == '2':
						indigo.actionGroup.execute(int(dev.pluginProps['metaDevOnAction']))	
					else:
						pass

	
				if self.logLevel > 0: indigo.server.log(u"Device \"%s\" has been toggled and is now %s" % \
					(dev.name, newState), type=logType)
				dev.updateStateOnServer("onOffState", newOnState)
			except:
				indigo.server.log(u"send \"%s\" %s failed" % (dev.name, "on"), isError=True, type=logType)

		###### SET BRIGHTNESS ######
		elif action.deviceAction == indigo.kDeviceAction.SetBrightness:
			try:
				if self.logLevel > 3: self.debugLog('device brightness set to:\n%s' % action)
				if brightMode == '2':
					indigo.actionGroup.execute(int(dev.pluginProps['metaDevBrightAction']))
				else:
					pass

				if self.logLevel > 0: indigo.server.log(u"Device \"%s\" brightness set to %s" \
					% (dev.name, action.actionValue), type=logType)
				dev.updateStateOnServer("brightnessLevel", action.actionValue)
			except exception, e:
				indigo.server.log(u"send \"%s\" set brightness to %s failed" % \
					(dev.name, action.actionValue, str(e)), isError=True, type=logType)
				
		###### BRIGHTEN BY ######
		elif action.deviceAction == indigo.kDeviceAction.BrightenBy:
			currentBrightness = int(dev.states['brightnessLevel'])
			newBrightness = currentBrightness + int(action.actionValue)
			try:
				if self.logLevel > 3: self.debugLog('device brighten by:\n%s' % action)
				if brightMode == '2':
					indigo.actionGroup.execute(int(dev.pluginProps['metaDevBrightAction']))
				else:
					pass

				if self.logLevel > 0: indigo.server.log(u"Device \"%s\" brightened to %s" \
					% (dev.name, newBrightness), type=logType)
				dev.updateStateOnServer("brightnessLevel", newBrightness)
			except:
				indigo.server.log(u"send \"%s\" brighten to %s failed" % \
					(dev.name, newBrightness), isError=True, type=logType)

		###### DIM BY ######
		elif action.deviceAction == indigo.kDeviceAction.DimBy:
			currentBrightness = int(dev.states['brightnessLevel'])
			newBrightness = currentBrightness - int(action.actionValue)
			try:
				if self.logLevel > 3: self.debugLog('device dim by:\n%s' % action)
				if brightMode == '2':
					indigo.actionGroup.execute(int(dev.pluginProps['metaDevBrightAction']))
				else:
					pass

				if self.logLevel > 0: indigo.server.log(u"Device \"%s\" dimmed to %s" \
					% (dev.name, newBrightness), type=logType)
				dev.updateStateOnServer("brightnessLevel", newBrightness)
			except:
				indigo.server.log(u"send \"%s\" dim to %s failed" % \
					(dev.name, newBrightness), isError=True, type=logType)
					
	########################################	
	# ConfigUI supporting methods
	########################################
	def getGroupSceneList(self, filter="", valuesDict=None, typeId="", targetId=0):
		myArray = []		
		sceneNames = os.popen("./scenenames.sh '" + indigo.server.getDbFilePath() + "'").read()
		
		for scene in sceneNames.split('\n'):
			pairs = scene.split(',', 1)
			if self.logLevel > 2: self.debugLog('SCENE num:%s, name:%s' % (pairs[0], pairs[-1]))
			if len(pairs[0]) >0:
				myArray.append((str(pairs[0]), str(pairs[0]) + ' - ' + str(pairs[-1])))
			
		return myArray
		
	########################################	
	# Action Callback methods
	########################################
	def setOnStateTrue(self, action):
		if self.logLevel > 2: indigo.server.log(u"Set device state True action called")
		if self.logLevel > 3: indigo.server.log("Action received: %s" % action)
		indigoDevice = indigo.devices[action.deviceId]
		indigoDevice.updateStateOnServer(key='onOffState', value='on')
		
	def setOnStateFalse(self, action):
		if self.logLevel > 2: indigo.server.log(u"Set device state False action called")
		if self.logLevel > 3: indigo.server.log("Action received: %s" % action)
		indigoDevice = indigo.devices[action.deviceId]
		indigoDevice.updateStateOnServer(key='onOffState', value='off')
		
	def setBrightnessLevel(self, action): # Contributed by @nathans
		if self.logLevel > 2: indigo.server.log(u"Set device brightness level action called")
		if self.logLevel > 3: indigo.server.log("Action received: %s" % action)
		indigoDevice = indigo.devices[action.deviceId]
		newBrightness = action.props.get('brightnessLevel', "")
		if len(newBrightness) > 0:
			if int(newBrightness) <= 100 and int(newBrightness) >= 0:
				indigoDevice.updateStateOnServer(key='brightnessLevel', value=newBrightness)
			else:
				self.errorLog("Brightness level specified (%s) is outside the acceptible brightness range." % newBrightness)
		else:
			self.errorLog("No brightness level was specified in action call.")
	
	########################################################
	# Validation methods for Plugin prefs and device config
	########################################################
	def validateDeviceConfigUi(self, valuesDict, typeId, devId):	
		if self.logLevel > 2: indigo.server.log(u"validating Device Config called")
		if self.logLevel > 3: self.debugLog('Device validation received:%s' % valuesDict)
		errorMsgDict = indigo.Dict()				
		valErrors = 0
		
		if valuesDict['metaDevOnMode'] == '1':	
			if valuesDict['metaDevGroupScene'] == '':
				valErrors = 1
				errorMsgDict['metaDevGroupScene'] = u"You must select a Group/Scene"
	
		elif valuesDict['metaDevOnMode'] == '2':
			if valuesDict['metaDevOnAction'] == '':
				valErrors = 1
				errorMsgDict['metaDevOnAction'] = u"You must select an Action Group for the On event"
						
			if valuesDict['metaDevOffAction'] == '':
				valErrors = 1
				errorMsgDict['metaDevOffAction'] = u"You must select an Action Group for the Off event"								

		if valErrors > 0:
			return (False, valuesDict, errorMsgDict)	
		else: 
			return (True, valuesDict)
			
	def validateActionConfigUi(self, valuesDict, typeId, devId):  # Contributed by @nathans
		  if self.logLevel > 2: indigo.server.log(u"validating Action Config called")
		  if self.logLevel > 3: self.debugLog('Action validation received:%s' % valuesDict)
		  errorMsgDict = indigo.Dict()            
		  valErrors = 0
		  
		  device = indigo.devices[devId]
		  descString = u""
		  
		  # Set Brightness
		  if typeId == "setBrightnessLevel":
				 try:
						brightnessLevel = int(valuesDict.get('brightnessLevel', ""))
				 except ValueError:
						errorMsgDict['brightnessLevel'] = u"The brightness level must be a whole number between 0 and 100."
						return (False, valuesDict, errorMsgDict)
				 
				 if (brightnessLevel < 0) or (brightnessLevel > 100):
						errorMsgDict['brightnessLevel'] = u"The brightness level must be between 0 and 100."
						return (False, valuesDict, errorMsgDict)
				 
				 descString += u"set device brightness level to " + str(brightnessLevel)
				 
				 return (True, valuesDict)
