#!/bin/sh
####################
# Copyright (c) 2012, Berkinet, (AKA Richard Perlman) All rights reserved.

/usr/bin/grep \<Name[0-9] "$1"|/usr/bin/sed -e s/^.*\<Name// -e s/type=\"string\"\>// -e s/\<.*\$// -e s/\ /,/|/usr/bin/sort -n

